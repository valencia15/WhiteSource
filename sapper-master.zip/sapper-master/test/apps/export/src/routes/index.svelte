<h1>Great success!</h1>

<a href="blog">blog</a>
<a href="">empty anchor</a>
<a href=''>empty anchor #2</a>
<a href=>empty anchor #3</a>
<a href= >empty anchor #4</a>
<a href>empty anchor #5</a>
<a>empty anchor #6</a>
<a href="boom">boom</a>
<a href="test.pdf">pdf file</a>