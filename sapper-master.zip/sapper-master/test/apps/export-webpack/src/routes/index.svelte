<h1>Great success!</h1>

<a href="blog">blog</a>
<a href="">empty anchor</a>