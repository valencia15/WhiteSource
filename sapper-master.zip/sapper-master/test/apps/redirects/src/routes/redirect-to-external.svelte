<script context="module">
	export function preload() {
		this.redirect(301, 'https://example.com');
	}
</script>

<h1>unredirected</h1>