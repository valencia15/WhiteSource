<script context="module">
	export function preload() {
		this.redirect(301, 'redirect-to');
	}
</script>

<h1>unredirected</h1>