<h1>root</h1>

<a href="redirect-from">redirect from</a>
<a href="redirect-to-root">redirect to root</a>
<a href="redirect-to-external">redirect to external</a>