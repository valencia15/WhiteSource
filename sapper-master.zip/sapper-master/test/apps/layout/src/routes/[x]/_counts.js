export default {
	x: process.browser ? 1 : 0,
	y: process.browser ? 1 : 0,
	z: process.browser ? 1 : 0
};