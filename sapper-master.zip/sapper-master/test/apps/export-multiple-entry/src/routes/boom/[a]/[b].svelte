<script context="module">
	export function preload({ params }) {
		return params;
	}
</script>

<script>
	export let a;
	export let b;
</script>

<p>{a}/{b}</p>