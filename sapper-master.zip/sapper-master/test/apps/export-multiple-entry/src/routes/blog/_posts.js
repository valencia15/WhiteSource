export default [
	{ slug: 'foo', title: 'once upon a foo' },
	{ slug: 'bar', title: 'a bar is born' },
	{ slug: 'baz', title: 'bazzily ever after' }
];