<h1>Foo</h1>

<style>
	h1 {
		color: blue;
	}
</style>