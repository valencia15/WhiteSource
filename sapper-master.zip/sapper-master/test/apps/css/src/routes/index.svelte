<h1>Great success!</h1>

<a href="foo">foo</a>
<a href="bar">bar</a>

<style>
	h1 {
		color: red;
	}
</style>