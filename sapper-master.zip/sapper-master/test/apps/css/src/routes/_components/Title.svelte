<h1>Title</h1>

<style>
	h1 {
		color: green;
	}
</style>