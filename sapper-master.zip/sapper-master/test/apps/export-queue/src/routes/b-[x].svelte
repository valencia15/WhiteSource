<script>
	export let x;
</script>

<p>b-{x}</p>
