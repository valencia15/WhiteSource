<h1>Another tall page</h1>

<div style="height: 9999px"></div>
<p id="bar">element</p>