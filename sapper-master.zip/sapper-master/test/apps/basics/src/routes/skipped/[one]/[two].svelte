<script context="module">
	export function preload({ params }) {
		return params;
	}
</script>

<script>
	export let one;
	export let two;
</script>

<h1>{one}:{two}</h1>

<a href="skipped/y/1">skipped/y/1</a>