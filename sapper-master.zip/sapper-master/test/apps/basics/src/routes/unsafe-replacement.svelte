<script context="module">
	export function preload() {
		return '$&';
	}
</script>

$&