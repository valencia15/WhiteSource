export function get(req, res) {
	res.end(JSON.stringify('b'));
}