<h1>foo</h1>
<a href="dirs/bar">bar</a>