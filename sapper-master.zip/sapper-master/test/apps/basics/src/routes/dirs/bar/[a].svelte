<h1>A page</h1>

<a href="dirs/foo/xyz">same segment</a>
