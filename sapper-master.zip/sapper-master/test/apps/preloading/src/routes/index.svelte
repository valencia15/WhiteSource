<h1>Great success!</h1>

<a href="slow-preload">slow preload</a>
<a href="foo">foo</a>
<a href="prefetch/qwe" rel=prefetch>prefetch qwe</a>
<a href="prefetch/xyz" rel=prefetch>prefetch xyz</a>
