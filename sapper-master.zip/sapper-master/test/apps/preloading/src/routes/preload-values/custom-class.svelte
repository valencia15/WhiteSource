<script context="module">
	export function preload() {
		class Foo {
			bar() {
				return 42;
			}
		}

		return {
			foo: new Foo()
		};
	}
</script>

<script>
	export let foo;
</script>

<h1>{foo.bar()}</h1>