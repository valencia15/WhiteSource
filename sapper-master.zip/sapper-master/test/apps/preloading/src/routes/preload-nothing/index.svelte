<script context="module">
	export function preload() {}
</script>

<h1>Page loaded</h1>
