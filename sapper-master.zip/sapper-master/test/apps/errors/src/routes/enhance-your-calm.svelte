<script context="module">
	export function preload() {
		this.error(420, 'Enhance your calm');
	}
</script>