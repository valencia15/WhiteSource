export function get(req, res) {
	res.writeHead(500);
	res.end('nope');
}