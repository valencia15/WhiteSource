<h1>root</h1>

<a href="nope">nope</a>
<a href="blog/nope">blog/nope</a>
<a href="throw">throw</a>