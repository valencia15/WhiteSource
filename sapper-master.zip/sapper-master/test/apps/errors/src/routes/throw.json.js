export function get(req, res) {
	throw new Error('oops');
}