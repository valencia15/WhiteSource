<script context="module">
	export function preload() {
		throw new Error('nope');
	}
</script>