export function get(req, res) {
  return Promise.reject(new Error('oops'));
}