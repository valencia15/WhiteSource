<script>
	export let error;
</script>

<h1>{error ? error.message : 'No error here'}</h1>

<a href="enhance-your-calm">Enhance your calm</a>