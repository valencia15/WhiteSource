import { writable } from 'svelte/store';

export const CONTEXT_KEY = {};

export const preload = () => ({});