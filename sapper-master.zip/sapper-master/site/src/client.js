import '@sveltejs/site-kit/base.css';
import * as sapper from '@sapper/app';

sapper.start({
	target: document.querySelector('#sapper')
});